'use strict';

/* App Module */

var siteApp = angular.module('siteApp' ,  ['ngRoute','ngResource','ngCookies','pascalprecht.translate']);