package com.kp.controllers;

import com.kp.dto.ExampleUserDetails;
import com.kp.model.user.User;
import com.kp.model.user.Role;
import com.kp.rest.TokenUtils;
import com.kp.security.MyUserDetailsService;
import com.kp.service.UserService;
import com.kp.transfer.TokenTransfer;
import com.kp.transfer.UserTransfer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.FormParam;
import javax.ws.rs.WebApplicationException;
import java.security.Principal;
import java.util.HashMap;
import java.util.Map;


/**
 * Created by user on 8/17/16.
 */
@RestController
public class LoginController {

    private static final Logger LOGGER = LoggerFactory.getLogger(LoginController.class);


    @Autowired
    UserService userService;

    private Authentication authentication;

    private Authentication getAuthentication(){
        Authentication temp=this.authentication;
        this.authentication=null;
        return  temp;
    }

    private void setAuthentication(Authentication authentication) {
        this.authentication = authentication;
    }

    @Autowired
    MyUserDetailsService myUserDetailService;

    @Autowired
    private AuthenticationManager authManager;



    @RequestMapping(value = "/user/authenticate", method = RequestMethod.POST)
    public TokenTransfer authenticate(@FormParam("username") String username, @FormParam("password") String password, HttpServletRequest request) {

        UsernamePasswordAuthenticationToken authenticationToken =
                new UsernamePasswordAuthenticationToken(username, password);
        Authentication authentication = this.authManager.authenticate(authenticationToken);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        setAuthentication(authentication);
        HttpSession session = request.getSession(true);
        session.setAttribute("SPRING_SECURITY_CONTEXT", SecurityContextHolder.getContext());

        UserDetails userDetails = this.myUserDetailService.loadUserByUsername(username);

        return new TokenTransfer(TokenUtils.createToken(userDetails));
    }

    @RequestMapping(value = "/user", method = RequestMethod.GET)
    public UserTransfer getUser()
    {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        //Object principal = authentication.getPrincipal();
        Object principal = getAuthentication().getPrincipal();
        if (principal instanceof String && (principal).equals("anonymousUser")) {
            throw new WebApplicationException(401);
        }
        ExampleUserDetails userDetails = (ExampleUserDetails) principal;

        return new UserTransfer(userDetails.getUsername());
    }

}


