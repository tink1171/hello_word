package com.kp.validation;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class usernameValidator implements ConstraintValidator<Validusername, String> {
	private Pattern pattern;
	private Matcher matcher;
	private static final String username_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@" + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

	@Override
	public void initialize(final Validusername constraintAnnotation) {
	}

	@Override
	public boolean isValid(final String username, final ConstraintValidatorContext context) {
		return (validateusername(username));
	}

	private boolean validateusername(final String username) {
		pattern = Pattern.compile(username_PATTERN);
		matcher = pattern.matcher(username);
		return matcher.matches();
	}
}