package com.kp.errors;

import javax.management.RuntimeErrorException;

/**
 * Created by diman on 05.08.16.
 */
public final class usernameExistsException extends RuntimeException {
	public usernameExistsException(final String message){
		super(message);
	}
}
