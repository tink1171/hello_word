package com.kp.service;

import com.kp.model.Page;

/**
 * Created by user on 8/12/16.
 */
public interface PageService {
    void savePage(Page page);
}
