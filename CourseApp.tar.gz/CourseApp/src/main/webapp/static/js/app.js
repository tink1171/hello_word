'use strict';

/* App Module */

var siteApp = angular.module('siteApp' , ['ngRoute']);