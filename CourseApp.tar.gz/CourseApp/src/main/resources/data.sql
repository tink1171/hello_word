INSERT INTO page(content_1,content_2,content_3,content_4,template)
VALUES ('content1','content2','content3','contetn4','3');