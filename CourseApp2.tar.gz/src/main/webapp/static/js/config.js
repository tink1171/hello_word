siteApp.config(['$routeProvider' , function($routeProvider){
    $routeProvider
        .when('/create-site',
            {
                templateUrl:"static/template/create-site.html",
                controller:'CreateSiteCtrl'
            })
        .when('/show-site',
            {
                templateUrl:"static/template/show-site.html",
                controller:'ShowSiteCtrl'
            })
        .when('/create-page',
            {
                templateUrl:"static/template/create-page.html",
                controller:'CreatePageCtrl'
            })
        .otherwise({
            redirectTo : '/'
    });

}]);