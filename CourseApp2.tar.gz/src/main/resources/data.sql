INSERT INTO page(content)
VALUES ('content');
