package com.kp.model;

import java.io.Serializable;


public interface BaseEntity extends Serializable {

}