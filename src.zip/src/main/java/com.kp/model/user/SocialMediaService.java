package com.kp.model.user;

/**
 * Created by diman on 12.08.16.
 */
public enum SocialMediaService {
	FACEBOOK,
	TWITTER
}
