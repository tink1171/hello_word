package com.kp.transfer;

/**
 * Created by alex on 5/14/2016.
 */
public class UrlTransfer {
    private String url;

    public UrlTransfer() {
    }

    public UrlTransfer(String url) {
        this.url = url;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
