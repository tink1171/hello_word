'use strict';

siteApp.factory('UserLoginService', function($resource) {

    return $resource('/user/:action', {},
        {
            authenticate: {
                method: 'POST',
                params: {'action' : 'authenticate'},
                headers : {'Content-Type': 'application/x-www-form-urlencoded'}
            },
            register:{
                method: 'POST',
                params: {'action' : 'register'},
                headers : {'Content-Type': 'application/x-www-form-urlencoded'}
            }
        }
    );
});